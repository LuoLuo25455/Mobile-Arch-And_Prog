package com.example.project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Permission extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 101;
    private Button allowButton;
    private Button denyButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        allowButton = findViewById(R.id.requestPermissionAllowButton);
        denyButton = findViewById(R.id.requestPermissionDenyButton);

        allowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the case where the user denies permission
                continueWithoutSms();
            }
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
        } else {
            sendSms();
        }
    }

    private void continueWithoutSms() {
        // Handle the scenario where the user denies SMS permission
        // You can continue with the app's functionality without sending SMS
        Toast.makeText(this, "SMS permission denied. App will continue without SMS functionality.", Toast.LENGTH_SHORT).show();
    }

    private void sendSms() {
        // Implement the logic to send SMS messages here
        // This code should be executed after obtaining SMS permission
        Toast.makeText(this, "SMS permission granted. Sending SMS...", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms();
            } else {
                continueWithoutSms();
            }
        }
    }
}
