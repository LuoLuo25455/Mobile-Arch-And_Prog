package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;


public class Login extends AppCompatActivity {

    private Button registerButton;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private CredentialDatabase dbHelper;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        registerButton = findViewById(R.id.registerButton);
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        dbHelper = new CredentialDatabase(this);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start RegisterActivity when "register" button is clicked
                Intent intent = new Intent(Login.this, Register.class);
                startActivity(intent);
            }
        });


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String userId = checkCredentials(username, password);

                // Check the credentials against the database
                if (userId != null) {
                    // Credentials are correct, allow login
                    // You can start the next activity or perform the desired action here
                    // For example, you can start a welcome screen:
                    Intent intent = new Intent(Login.this, List.class);
                    intent.putExtra("userId", userId);
                    startActivity(intent);
                } else {
                    // Credentials are incorrect, display an error message or take appropriate action
                    Toast.makeText(Login.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Function to check the credentials in the database
    private String checkCredentials(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                CredentialDatabase.CredentialTable.TABLE,
                new String[]{CredentialDatabase.CredentialTable.COL_ID},
                CredentialDatabase.CredentialTable.USERNAME + " = ? AND " + CredentialDatabase.CredentialTable.PASSWORD + " = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        String userId = null;
        if(cursor.moveToFirst()){
            userId = cursor.getString(cursor.getColumnIndexOrThrow(CredentialDatabase.CredentialTable.COL_ID));
        }

        cursor.close();
        return userId;
    }
}
