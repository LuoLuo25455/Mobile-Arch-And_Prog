package com.example.project2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.time.chrono.ThaiBuddhistEra;
import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tracker.db";
    private static final int VERSION = 1;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static final class TrackerTable {
        public static final String TABLE = "Tracker";
        public static final String USER_ID = "userId";
        public static final String COL_ID = "_id";
        public static final String COL_TITLE = "Trail";
        public static final String DESCRIPTION = "Description";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TrackerTable.TABLE + " (" +
                TrackerTable.USER_ID + " integer, " +
                TrackerTable.COL_ID + " integer primary key autoincrement, " +
                TrackerTable.COL_TITLE + " text, " +
                TrackerTable.DESCRIPTION + " text, " +
                " FOREIGN KEY (" + TrackerTable.USER_ID + ") REFERENCES " + CredentialDatabase.CredentialTable.TABLE + "(" + CredentialDatabase.CredentialTable.COL_ID + ")" +
                " )"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + TrackerTable.TABLE);
        onCreate(db);
    }

    public void loadDataAndUpdateListView(ListView dataListView, Context context) {
        // Open the database for reading
        SQLiteDatabase db = getReadableDatabase();

        // Define a projection (the columns to retrieve from the table)
        String[] projection = {
                TrackerTable.USER_ID,
                TrackerTable.COL_ID,
                TrackerTable.COL_TITLE,
                TrackerTable.DESCRIPTION
        };


        // Perform a query on the Tracker table
        Cursor cursor = db.query(
                TrackerTable.TABLE,  // The table to query
                projection,          // The columns to retrieve
                null,                // The columns for the WHERE clause
                null,                // The values for the WHERE clause
                null,                // Don't group the rows
                null,                // Don't filter by row groups
                null            // The sort order
        );

        // Create an ArrayList to hold the data
        ArrayList<String> dataList = new ArrayList<>();

        // Iterate through the cursor and populate the ArrayList
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(TrackerTable.COL_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(TrackerTable.COL_TITLE));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(TrackerTable.DESCRIPTION));

            // Add the data to the ArrayList (you can modify this based on your data structure)
            dataList.add(title + "\n" + description);
        }

        // Close the cursor and the database
        cursor.close();
        db.close();

        // Create an ArrayAdapter to display the data in the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, dataList);

        // Set the adapter on the dataListView
        dataListView.setAdapter(adapter);
    }

    public void deleteAndRenumber(long id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete the row with the given primary key
        db.delete(TrackerTable.TABLE, TrackerTable.COL_ID + " = ?", new String[] { Long.toString(id) });

        // After deletion, update the primary keys to renumber them
        String updateSql = "UPDATE " + TrackerTable.TABLE + " SET " + TrackerTable.COL_ID + " = " +
                TrackerTable.COL_ID + " - 1 WHERE " + TrackerTable.COL_ID + " > ?";

        db.execSQL(updateSql, new String[] { Long.toString(id) });

        db.close();
    }

}
