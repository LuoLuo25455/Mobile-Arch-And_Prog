package com.example.project2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class List extends AppCompatActivity {

    private LinearLayout customRowLayout;
    private ListView dataListView;
    private TextView textView;
    private Button addButton;
    private Button saveButton;
    private Button deleteButton;
    private EditText itemNameEditText;
    private EditText editDateEditText;
    private boolean isEditing = false; // Initially not editing
    private Database database;
    private String loggedInUserId;
    private long itemID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        Intent intent = getIntent();
        loggedInUserId = intent.getStringExtra("userId");

        customRowLayout = findViewById(R.id.customRowLayout);
        dataListView = findViewById(R.id.dataListView);
        textView = findViewById(R.id.headerText);
        addButton = findViewById(R.id.addButton);
        saveButton = findViewById(R.id.saveButton);
        itemNameEditText = findViewById(R.id.itemName);
        editDateEditText = findViewById(R.id.editDate);
        deleteButton = findViewById(R.id.cancelButton);

        // Initialize the database
        database = new Database(this);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Toggle editing mode
                isEditing = true;
                updateUI();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isEditing) {
                    // Get the entered values
                    String itemName = itemNameEditText.getText().toString();
                    String editDate = editDateEditText.getText().toString();

                    if (!itemName.isEmpty() && !editDate.isEmpty()) {
                        SQLiteDatabase db = database.getWritableDatabase();

                        // Check if the item already exists
                        String selection = Database.TrackerTable.COL_ID + " = ?";
                        String[] selectionArgs = {String.valueOf(itemID)};

                        Cursor cursor = db.query(
                                Database.TrackerTable.TABLE,
                                null,
                                selection,
                                selectionArgs,
                                null,
                                null,
                                null
                        );

                        ContentValues values = new ContentValues();
                        values.put(Database.TrackerTable.USER_ID, loggedInUserId);
                        values.put(Database.TrackerTable.COL_TITLE, itemName);
                        values.put(Database.TrackerTable.DESCRIPTION, editDate);

                        if (cursor.getCount() > 0) {
                            // Item already exists; update it
                            db.update(
                                    Database.TrackerTable.TABLE,
                                    values,
                                    selection,
                                    selectionArgs
                            );
                            cursor.close();
                            db.close();

                            Toast.makeText(List.this, "Data updated in the database", Toast.LENGTH_SHORT).show();
                        } else {
                            // Item doesn't exist; insert it as a new row
                            db.insert(Database.TrackerTable.TABLE, null, values);
                            cursor.close();
                            db.close();

                            Toast.makeText(List.this, "Data inserted in the database", Toast.LENGTH_SHORT).show();
                        }

                        isEditing = false;
                        updateUI();
                    } else {
                        Toast.makeText(List.this, "Please fill in both fields before saving.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        dataListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                itemID = id;
                isEditing = true;
                updateUI();

                System.out.println(itemID);



                String title = "";
                String description = "";

                SQLiteDatabase db = database.getReadableDatabase();

                String[] projection = {
                        Database.TrackerTable.COL_TITLE,
                        Database.TrackerTable.DESCRIPTION
                };

                String selection = Database.TrackerTable.COL_ID + " = ?";
                String[] selectionArgs = {String.valueOf(itemID)};

                Cursor cursor = db.query(
                        Database.TrackerTable.TABLE,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        null
                );

                if(cursor.moveToFirst()){
                    title = cursor.getString(cursor.getColumnIndexOrThrow(Database.TrackerTable.COL_TITLE));
                    description = cursor.getString(cursor.getColumnIndexOrThrow(Database.TrackerTable.DESCRIPTION));

                }

                cursor.close();
                db.close();

                // Populate the EditText boxes with the selected item and description
                itemNameEditText.setText(title);
                editDateEditText.setText(description);

                // Switch to the customRowLayout
                isEditing = true;
                updateUI();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                database.deleteAndRenumber(itemID);

                Toast.makeText(List.this, "Entry deleted", Toast.LENGTH_SHORT).show();

                // Update the UI to show the dataListView
                isEditing = false;
                updateUI();

                // Re-query the database and update the dataListView
                database.loadDataAndUpdateListView(dataListView, getBaseContext());

            }
        });



        // Call updateUI initially to set the visibility
        updateUI();
    }

    private void updateUI() {
        if (isEditing) {
            // Show the customRowLayout and hide the dataListView
            customRowLayout.setVisibility(View.VISIBLE);
            dataListView.setVisibility(View.GONE);
            textView.setVisibility(View.GONE);
        } else {
            // Hide the customRowLayout and show the dataListView
            customRowLayout.setVisibility(View.GONE);
            dataListView.setVisibility(View.VISIBLE);
            textView.setVisibility(View.VISIBLE);

            database.loadDataAndUpdateListView(dataListView, getBaseContext());
        }
    }

    @Override
    public void onBackPressed() {
        if (isEditing) {
            // If isEditing is true, switch back to dataListView
            isEditing = false;
            updateUI();
        } else {
            super.onBackPressed();
        }
    }

    private boolean checkForDuplicate(SQLiteDatabase db, String title, String description, String userId) {
        String[] projection = {
                Database.TrackerTable.COL_ID
        };
        String selection =
                Database.TrackerTable.USER_ID + " = ? AND " +
                Database.TrackerTable.COL_TITLE + " = ? AND " +
                Database.TrackerTable.DESCRIPTION + " = ?";
        String[] selectionArgs = {userId, title, description};

        Cursor cursor = db.query(
                Database.TrackerTable.TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

}