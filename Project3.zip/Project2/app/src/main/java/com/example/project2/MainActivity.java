package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // show Hello screen upon opening up the app
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // wait for 5 secs after the Hello screen, then show Login screen
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // switch from Hello to Login
                Intent intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);

                // prevent the screen from going back to Hello screen
                finish();
            }
        }, 5000);
    }
}
