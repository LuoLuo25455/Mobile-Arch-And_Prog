package com.example.project2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.chrono.ThaiBuddhistEra;

public class CredentialDatabase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "credentials.db";
    private static final int VERSION = 1;

    public CredentialDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static final class CredentialTable {
        public static final String TABLE = "Credentials";
        public static final String COL_ID = "userId";
        public static final String USERNAME = "username";
        public static final String PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + CredentialTable.TABLE + " (" +
                CredentialTable.COL_ID + " integer primary key autoincrement, " +
                CredentialTable.USERNAME + " text, " +
                CredentialTable.PASSWORD + " text" +
                " )"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + CredentialTable.TABLE);
        onCreate(db);
    }
}
