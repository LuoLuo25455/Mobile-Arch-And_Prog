package com.example.project2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


public class Register extends AppCompatActivity {
    private Button loginButton;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button registerButton;
    private CredentialDatabase dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // show Hello screen upon opening up the app
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        loginButton = findViewById(R.id.loginButton);
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        registerButton = findViewById(R.id.registerButton);
        dbHelper = new CredentialDatabase(this);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start RegisterActivity when "register" button is clicked
                Intent intent = new Intent(Register.this, Login.class);
                startActivity(intent);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Register.this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (isUsernameTaken(username)) {
                    // Display a warning if the username is already in use
                    Toast.makeText(Register.this, "Username already in use", Toast.LENGTH_SHORT).show();
                } else {
                    // Store the user's credentials in the database
                    if (storeCredentials(username, password)) {
                        // Registration successful
                        Toast.makeText(Register.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    } else {
                        // Registration failed
                        Toast.makeText(Register.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    // Function to check if the username is already taken
    private boolean isUsernameTaken(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                CredentialDatabase.CredentialTable.TABLE,
                null,
                CredentialDatabase.CredentialTable.USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean isTaken = cursor.getCount() > 0;
        cursor.close();
        return isTaken;
    }

    // Function to store the user's credentials in the database
    private boolean storeCredentials(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CredentialDatabase.CredentialTable.USERNAME, username);
        values.put(CredentialDatabase.CredentialTable.PASSWORD, password);

        long newRowId = db.insert(CredentialDatabase.CredentialTable.TABLE, null, values);
        db.close();

        return newRowId != -1; // Check if the insertion was successful
    }


}
